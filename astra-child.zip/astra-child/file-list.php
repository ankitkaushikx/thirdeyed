<?php
/*
Template Name: User Uploaded Files
*/
get_header();

if (is_user_logged_in()) {
    $current_user = wp_get_current_user();
    $user_id = $current_user->ID;
    $uploaded_files = array();

    // Loop through to get all uploaded files
    for ($i = 1; $i <= 3; $i++) {
        $attachment_id = get_user_meta($user_id, 'uploaded_file_' . $i, true);
        if ($attachment_id) {
            $file_info = get_post($attachment_id);
            $uploaded_files[] = $file_info;
        }
    }

    if (!empty($uploaded_files)) {
        echo '<h2>Your Uploaded Files</h2>';
        echo '<table>';
        echo '<thead>';
        echo '<tr>';
        echo '<th>File Name</th>';
        echo '<th>Preview</th>';
        echo '<th>Download</th>';
        echo '<th>Delete</th>';
        echo '</tr>';
        echo '</thead>';
        echo '<tbody>';
        foreach ($uploaded_files as $file_info) {
            $file_url = wp_get_attachment_url($file_info->ID);
            $file_name = esc_html($file_info->post_title);
            $file_id = $file_info->ID;
            echo '<tr>';
            echo '<td><a href="' . $file_url . '" target="_blank">' . $file_name . '</a></td>';
            echo '<td><a href="' . $file_url . '" target="_blank">Preview</a></td>';
            echo '<td><a href="' . $file_url . '" download>Download</a></td>';
            echo '<td><button class="delete-file" data-file-id="' . $file_id . '">Delete</button></td>';
            echo '</tr>';
        }
        echo '</tbody>';
        echo '</table>';
    } else {
        echo '<p>No files uploaded yet.</p>';
    }
} else {
    echo '<p>Please <a href="' . wp_registration_url() . '">register</a> or <a href="' . wp_login_url() . '">log in</a> to view your uploaded files.</p>';
}

get_footer();
?>

<script>
    jQuery(document).ready(function ($) {
        $('.delete-file').on('click', function () {
            var fileId = $(this).data('file-id');
            var confirmDelete = confirm('Are you sure you want to delete this file?');
            if (confirmDelete) {
                $.ajax({
                    type: 'POST',
                    url: ajaxurl,
                    data: {
                        action: 'delete_uploaded_file',
                        file_id: fileId
                    },
                    success: function (response) {
                        if (response === 'success') {
                            alert('File deleted successfully.');
                            location.reload();
                        } else {
                            alert('Error deleting file.');
                        }
                    }
                });
            }
        });
    });
</script>
