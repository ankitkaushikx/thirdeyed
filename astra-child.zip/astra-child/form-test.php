<?php
/*
Template Name: Upload Multiple Files
*/
get_header();

if (isset($_POST['upload']) && is_user_logged_in()) {
    $user = wp_get_current_user();
    $file_ids = array();

    // Loop through the file input fields and handle each file
    for ($i = 1; $i <= 3; $i++) {
        $file_field_name = 'file_upload_' . $i;
        $file = $_FILES[$file_field_name];

        // Check if the file was uploaded successfully
        if ($file['error'] === UPLOAD_ERR_OK) {
            // Create a new file name with the format "username-filename"
            $new_file_name = $user->user_login . '-' . sanitize_file_name($file['name']);

            // Move the uploaded file to the WordPress uploads directory with the new name
            $upload_dir = wp_upload_dir();
            $file_path = $upload_dir['path'] . '/' . $new_file_name;
            move_uploaded_file($file['tmp_name'], $file_path);

            // Create an attachment post for the file
            $attachment = array(
                'post_title' => $new_file_name,
                'post_content' => '',
                'post_status' => 'inherit',
                'post_mime_type' => $file['type'],
            );

            $attachment_id = wp_insert_attachment($attachment, $file_path);

            // Generate metadata for the attachment and update the database record
            require_once(ABSPATH . 'wp-admin/includes/image.php');
            $attachment_data = wp_generate_attachment_metadata($attachment_id, $file_path);
            wp_update_attachment_metadata($attachment_id, $attachment_data);

            // Attach the file to the user's account using user meta
            update_user_meta($user->ID, 'uploaded_file_' . $i, $attachment_id);

            // Store the attachment ID for reference
            $file_ids[] = $attachment_id;
        }
    }

    if (!empty($file_ids)) {
        echo 'Files uploaded successfully:';
        foreach ($file_ids as $file_id) {
            echo '<br>' . get_the_title($file_id);
        }
    } else {
        echo 'No files uploaded.';
    }
} elseif (!is_user_logged_in()) {
    echo 'Please <a href="' . wp_registration_url() . '">register</a> or <a href="' . wp_login_url() . '">log in</a> to upload files.';
}
?>

<?php if (is_user_logged_in()) : ?>
    <form action="" method="post" enctype="multipart/form-data">
        <label for="file_upload_1">Select File 1:</label>
        <input type="file" name="file_upload_1" id="file_upload_1" accept=".pdf,.doc,.docx,.jpg,.jpeg,.png" required>
        <br>
        <label for="file_upload_2">Select File 2:</label>
        <input type="file" name="file_upload_2" id="file_upload_2" accept=".pdf,.doc,.docx,.jpg,.jpeg,.png" required>
        <br>
        <label for="file_upload_3">Select File 3:</label>
        <input type="file" name="file_upload_3" id="file_upload_3" accept=".pdf,.doc,.docx,.jpg,.jpeg,.png" required>
        <br>
        <input type="submit" name="upload" value="Upload Files">
    </form>
<?php else : ?>
    <p>Please <a href="<?php echo wp_registration_url(); ?>">register</a> or <a href="<?php echo wp_login_url(); ?>">log in</a> to upload files.</p>
<?php endif; ?>

<?php get_footer(); ?>
