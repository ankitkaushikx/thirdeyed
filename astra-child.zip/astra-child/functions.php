<?php
add_action( 'wp_enqueue_scripts', 'my_child_theme_enqueue_styles' );
function my_child_theme_enqueue_styles() {
wp_enqueue_style( 'parent-style', get_template_directory_uri() . '/style.css' );
wp_enqueue_style( 'child-style', get_stylesheet_directory_uri() . '/style.css', array(
'parent-style' ) );
}

function enqueue_custom_styles() {
    // Enqueue your custom CSS file from the child theme
    wp_enqueue_style('custom-styles', get_stylesheet_directory_uri() . '/custom-style.css', array(), '1.0', 'all');
}

// Hook the function to the wp_enqueue_scripts action
add_action('wp_enqueue_scripts', 'enqueue_custom_styles');


function enqueue_jquery() {
    wp_enqueue_script('jquery');
}
add_action('wp_enqueue_scripts', 'enqueue_jquery');

function custom_scripts() {
    wp_enqueue_script('custom-script', get_stylesheet_directory_uri() . '/js/custom-script.js', array('jquery'), '1.0', true);
    wp_localize_script('custom-script', 'custom_script_vars', array(
        'ajaxurl' => admin_url('admin-ajax.php')
    ));
}
add_action('wp_enqueue_scripts', 'custom_scripts');


function rename_uploaded_file() {
    if (isset($_POST['current_file_name']) && isset($_POST['new_file_name'])) {
        $currentFileName = sanitize_file_name($_POST['current_file_name']);
        $newFileName = sanitize_file_name($_POST['new_file_name']);

        // Get the attachment ID from the user meta
        $user = wp_get_current_user();
        $user_id = $user->ID;
        $file_ids = get_user_meta($user_id, 'uploaded_file_ids', true);

        // Find the attachment ID associated with the current file name
        $attachmentId = null;
        if (!empty($file_ids) && is_array($file_ids)) {
            foreach ($file_ids as $fileId => $fileName) {
                if ($fileName === $currentFileName) {
                    $attachmentId = $fileId;
                    break;
                }
            }
        }

        if ($attachmentId) {
            // Update the attachment's post_title (file name)
            $attachmentData = array(
                'ID' => $attachmentId,
                'post_title' => $newFileName
            );
            wp_update_post($attachmentData);

            // Update the user's meta data with the new file name
            $file_ids[$attachmentId] = $newFileName;
            update_user_meta($user_id, 'uploaded_file_ids', $file_ids);

            echo 'success';
        } else {
            echo 'error';
        }
    }
    wp_die();
}

add_action('wp_ajax_rename_uploaded_file', 'rename_uploaded_file');
add_action('wp_ajax_nopriv_rename_uploaded_file', 'rename_uploaded_file');
