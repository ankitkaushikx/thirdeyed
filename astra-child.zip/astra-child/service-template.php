<?php
/**
 * Template Name: Custom Template
 * Description: A custom template for creating new posts.
 */

// Get the page content
$page_content = get_post_field('post_content', get_the_ID());

// Output the page content
echo wpautop($page_content);

// Check if the form is submitted
if (isset($_POST['submit_post'])) {
    // Check if the user is logged in
    if (is_user_logged_in()) {
        // Get the current user's ID
        $current_user = wp_get_current_user();
        $author_id = $current_user->ID;

        // Retrieve form data
        $post_title = sanitize_text_field($_POST['post_title']);
        $post_content = wp_kses_post($_POST['post_content']);

        // Create a new post
        $new_post = array(
            'post_title' => $post_title,
            'post_content' => $post_content,
            'post_author' => $author_id,
            'post_status' => 'publish', // You can change the status as needed
            'post_type' => 'post', // Change to your custom post type if necessary
        );

        // Insert the post into the database
        $post_id = wp_insert_post($new_post);

        if ($post_id) {
            echo '<p class="success-message">Post created successfully!</p>';
        } else {
            echo '<p class="error-message">Error creating the post. Please try again.</p>';
        }
    } else {
        echo '<p class="error-message">You must be logged in to create a post.</p>';
    }
}
?>

<form id="new-post-form" method="post" action="">
    <label for="post-title">Post Title:</label>
    <input type="text" id="post-title" name="post_title" required>

    <label for="post-content">Post Content:</label>
    <textarea id="post-content" name="post_content" rows="4" required></textarea>

    <input type="submit" name="submit_post" value="Submit">
</form>
