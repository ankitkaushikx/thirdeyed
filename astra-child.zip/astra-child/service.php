<?php
/*
Template Name: Service One
*/
?>
    <div class="container">
        <h1>Service Request Form</h1>
        <form action="#" method="post">
            <div class="mb-3">
                <label for="service_name" class="form-label">Name of Service</label>
                <input type="text" class="form-control" id="service_name" name="service_name" required>
            </div>
            <div class="mb-3">
                <label for="person_type" class="form-label">Person Type</label>
                <select class="form-select" id="person_type" name="person_type" required>
                    <option value="" disabled selected>Select Person Type</option>
                    <option value="option_1">Option 1</option>
                    <option value="option_2">Option 2</option>
                    <option value="option_3">Option 3</option>
                </select>
            </div>
            <div class="mb-3">
                <label for="field_1" class="form-label">Field 1</label>
                <input type="text" class="form-control" id="field_1" name="field_1" required>
            </div>
            <div class="mb-3">
                <label for="field_2" class="form-label">Field 2</label>
                <input type="text" class="form-control" id="field_2" name="field_2" required>
            </div>
            <div class="mb-3">
                <label for="field_3" class="form-label">Field 3</label>
                <input type="text" class="form-control" id="field_3" name="field_3" required>
            </div>
            <button type="submit" class="btn btn-primary">Submit</button>
        </form>
    </div>