<?php
/*
Template Name: Show All Services
*/
get_header(); // Include your header template
?>

<section class="custom-service">
    <div class="container">
        <h1 class="custom-service-title"><?php the_title(); ?></h1>
        <div class="custom-service-list">
            <?php
            $args = array(
                'post_type' => 'service', // Replace with your custom post type name
                'posts_per_page' => -1,   // Display all posts
            );

            $service_query = new WP_Query($args);

            if ($service_query->have_posts()) :
                while ($service_query->have_posts()) :
                    $service_query->the_post();
                    ?>
                    <article id="post-<?php the_ID(); ?>" <?php post_class('custom-service-item'); ?>>
                        <h2 class="custom-service-item-title"><?php the_title(); ?></h2>
                        <div class="custom-service-item-content">
                            <?php the_content(); ?>
                        </div>
                    </article>
                    <?php
                endwhile;
                wp_reset_postdata();
            else :
                // If no custom posts are found
                ?>
                <p>No services found.</p>
            <?php
            endif;
            ?>
        </div>
    </div>
</section>

<?php get_footer(); // Include your footer template ?>
